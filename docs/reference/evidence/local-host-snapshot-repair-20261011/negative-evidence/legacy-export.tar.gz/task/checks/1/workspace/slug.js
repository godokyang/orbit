export function slug(value) { return value.trim().replace(/\s+/g, "-").toLowerCase(); }

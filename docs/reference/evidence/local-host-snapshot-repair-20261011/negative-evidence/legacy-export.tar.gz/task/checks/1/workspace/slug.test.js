import assert from "node:assert/strict"; import {slug} from "./slug.js"; assert.equal(slug(" One two "), "one-two"); assert.equal(slug("One   two"), "one-two"); assert.equal(slug(""), "");

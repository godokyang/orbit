Work only inside this fixture; no commits, no members, no external writes.

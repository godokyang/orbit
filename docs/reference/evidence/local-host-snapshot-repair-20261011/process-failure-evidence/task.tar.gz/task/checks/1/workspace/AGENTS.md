Only read project files; no members, commits or external writes.

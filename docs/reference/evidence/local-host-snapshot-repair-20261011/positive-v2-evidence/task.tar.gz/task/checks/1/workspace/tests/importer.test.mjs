import { test } from 'node:test';
import assert from 'node:assert/strict';

import { importInvoices } from '../src/importer.mjs';

const HEADER = 'invoice_id,customer,amount,currency';

test('parses quoted fields: commas are literal and "" escapes a quote', () => {
  const csv =
    [
      HEADER,
      'INV-1,"Acme, Inc.",12.34,USD',
      'INV-2,"He said ""hi""",7,CNY',
    ].join('\n') + '\n';

  const { records, errors } = importInvoices(csv);

  assert.deepEqual(errors, []);
  assert.deepEqual(records, [
    { invoice_id: 'INV-1', customer: 'Acme, Inc.', amount_cents: 1234, currency: 'USD' },
    { invoice_id: 'INV-2', customer: 'He said "hi"', amount_cents: 700, currency: 'CNY' },
  ]);
});

test('accepts CRLF row endings and a trailing newline', () => {
  const csv =
    'invoice_id,customer,amount,currency\r\n' +
    'INV-1,Acme,12.34,USD\r\n' +
    'INV-2,Beta,5,CNY\r\n';

  const { records, errors } = importInvoices(csv);

  assert.deepEqual(errors, []);
  assert.deepEqual(records, [
    { invoice_id: 'INV-1', customer: 'Acme', amount_cents: 1234, currency: 'USD' },
    { invoice_id: 'INV-2', customer: 'Beta', amount_cents: 500, currency: 'CNY' },
  ]);
});

test('converts integer and 2-decimal amounts to exact cents', () => {
  const csv = [
    HEADER,
    'A,acme,12,CNY',
    'B,beta,12.34,USD',
    'C,gamma,0.05,CNY',
    'D,delta,0,USD',
    'E,eps,12.3,CNY',
    'F,zeta,12.345,USD',
    'G,eta,-1.00,CNY',
    'H,theta,abc,USD',
  ].join('\n');

  const { records, errors } = importInvoices(csv);

  assert.deepEqual(
    records.map((record) => record.amount_cents),
    [1200, 1234, 5, 0],
  );
  assert.deepEqual(errors, [
    { line: 6, code: 'bad_amount' },
    { line: 7, code: 'bad_amount' },
    { line: 8, code: 'bad_amount' },
    { line: 9, code: 'bad_amount' },
  ]);
});

test('rejects a repeated invoice_id from the second occurrence on', () => {
  const csv = [HEADER, '1,Acme,10.00,CNY', '2,Beta,20.00,USD', '1,Gamma,30.00,CNY'].join('\n');

  const { records, errors } = importInvoices(csv);

  assert.deepEqual(
    records.map((record) => record.invoice_id),
    ['1', '2'],
  );
  assert.equal(records[0].customer, 'Acme');
  assert.deepEqual(errors, [{ line: 4, code: 'duplicate_id' }]);
});

test('reports bad_header when the header line is not exact', () => {
  const wrongHeader = importInvoices('id,customer,amount,currency\n1,Acme,1.00,CNY\n');
  assert.deepEqual(wrongHeader, { records: [], errors: [{ line: 1, code: 'bad_header' }] });

  const empty = importInvoices('');
  assert.deepEqual(empty, { records: [], errors: [{ line: 1, code: 'bad_header' }] });
});

test('rejects a record with an unclosed quote at its starting line', () => {
  const csv = [HEADER, '1,Acme,10.00,CNY', '2,"Beta,20.00,CNY'].join('\n') + '\n';

  const { records, errors } = importInvoices(csv);

  assert.deepEqual(records, [
    { invoice_id: '1', customer: 'Acme', amount_cents: 1000, currency: 'CNY' },
  ]);
  assert.deepEqual(errors, [{ line: 3, code: 'unclosed_quote' }]);
});

test('line numbers start at 2 and multi-line quoted fields count from their start', () => {
  const csv = [
    HEADER, // line 1
    '1,"Acme\nCorp",10.00,CNY', // lines 2-3
    '2,Beta,abc,USD', // line 4
    '3,Gamma,5.00,XYZ', // line 5
    '4,Delta,6.00', // line 6
    '5,Epsilon,9.99,USD', // line 7
  ].join('\n');

  const { records, errors } = importInvoices(csv);

  assert.deepEqual(records, [
    { invoice_id: '1', customer: 'Acme\nCorp', amount_cents: 1000, currency: 'CNY' },
    { invoice_id: '5', customer: 'Epsilon', amount_cents: 999, currency: 'USD' },
  ]);
  assert.deepEqual(errors, [
    { line: 4, code: 'bad_amount' },
    { line: 5, code: 'bad_currency' },
    { line: 6, code: 'bad_field_count' },
  ]);
});

test('reports several errors for one row in field order', () => {
  const csv = [HEADER, ',,abc,XYZ'].join('\n');

  const { records, errors } = importInvoices(csv);

  assert.deepEqual(records, []);
  assert.deepEqual(errors, [
    { line: 2, code: 'missing_field' },
    { line: 2, code: 'missing_field' },
    { line: 2, code: 'bad_amount' },
    { line: 2, code: 'bad_currency' },
  ]);
});

test('reports bad_field_count for rows without exactly four fields', () => {
  const csv = [HEADER, '1,Acme,10.00,CNY,extra', '2,Beta,10.00'].join('\n');

  const { records, errors } = importInvoices(csv);

  assert.deepEqual(records, []);
  assert.deepEqual(errors, [
    { line: 2, code: 'bad_field_count' },
    { line: 3, code: 'bad_field_count' },
  ]);
});

test('reports missing_field for an empty invoice_id or customer', () => {
  const csv = [HEADER, ',Acme,10.00,CNY', '2,,10.00,CNY'].join('\n');

  const { records, errors } = importInvoices(csv);

  assert.deepEqual(records, []);
  assert.deepEqual(errors, [
    { line: 2, code: 'missing_field' },
    { line: 3, code: 'missing_field' },
  ]);
});

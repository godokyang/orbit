import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const here = path.dirname(fileURLToPath(import.meta.url));
const cli = path.join(here, '..', 'src', 'cli.mjs');

const run = (args) => spawnSync(process.execPath, [cli, ...args], { encoding: 'utf8' });

test('cli exits 0 and prints the result JSON for a fully valid file', () => {
  const r = run([path.join(here, 'fixtures', 'valid.csv')]);
  assert.equal(r.status, 0);
  assert.deepEqual(JSON.parse(r.stdout), {
    records: [
      { invoice_id: 'INV-001', customer: 'Acme, Inc.', amount_cents: 1234, currency: 'CNY' },
      { invoice_id: 'INV-002', customer: 'Globex', amount_cents: 10000, currency: 'USD' },
    ],
    errors: [],
  });
});

test('cli exits 2 and still prints the result JSON when rows have errors', () => {
  const r = run([path.join(here, 'fixtures', 'bad.csv')]);
  assert.equal(r.status, 2);
  assert.deepEqual(JSON.parse(r.stdout), {
    records: [{ invoice_id: 'INV-001', customer: 'Acme', amount_cents: 1234, currency: 'CNY' }],
    errors: [{ line: 3, code: 'bad_amount' }],
  });
});

test('cli exits 1 with a stderr explanation for an unreadable file', () => {
  const r = run([path.join(here, 'fixtures', 'no-such-file.csv')]);
  assert.equal(r.status, 1);
  assert.equal(r.stdout, '');
  assert.ok(r.stderr.trim().length > 0);
});

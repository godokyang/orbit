# Invoice CSV Import

发票 CSV 导入工具：把固定表头的发票 CSV 解析为 JSON 记录，坏行逐条报告，不中断有效行的导入。

## 运行环境

- 纯 Node（ESM），零第三方依赖。
- 项目自带真实 Node 副本 `.runtime/node`，以下命令都在项目根目录执行，不需要用户全局 Node。

## 运行方式

```sh
.runtime/node src/cli.mjs path/to/invoices.csv
```

- stdout 输出与导入结果相同的 JSON：`{"records":[...],"errors":[...]}`
- 退出码：
  - `0`：全部行有效；
  - `1`：文件无法读取（或未提供路径），stderr 给出原因；
  - `2`：存在错误行（有效行仍会出现在 `records` 中）。

### 输出示例

输入 `sample.csv`：

```csv
invoice_id,customer,amount,currency
INV-001,"Acme, Inc.",12.34,CNY
INV-002,Globex,100,USD
INV-003,Oops,-5.00,USD
```

```sh
.runtime/node src/cli.mjs sample.csv   # 退出码 2
```

```json
{
  "records": [
    { "invoice_id": "INV-001", "customer": "Acme, Inc.", "amount_cents": 1234, "currency": "CNY" },
    { "invoice_id": "INV-002", "customer": "Globex", "amount_cents": 10000, "currency": "USD" }
  ],
  "errors": [{ "line": 4, "code": "bad_amount" }]
}
```

## 解析规则

- 表头（第 1 行）必须恰好是 `invoice_id,customer,amount,currency`，否则报 `bad_header`（`line: 1`）。
- 支持双引号字段：字段内逗号按字面处理，`""` 转义为 `"`；行结束支持 LF 与 CRLF，允许文件末尾换行。
- 未闭合引号报 `unclosed_quote`。
- 金额必须是非负十进制字符串：整数或恰好两位小数（`12`、`12.34` 合法；`12.3`、`12.345`、`-1.00` 非法），报 `bad_amount`。内部用字符串处理转成整数分（`12.34` → `1234`，`12` → `1200`），全程不做浮点运算。
- 币种仅接受 `CNY` / `USD`，否则报 `bad_currency`。
- `invoice_id` 与 `customer` 必填非空，否则报 `missing_field`。
- 一行字段数不是 4 报 `bad_field_count`。
- 重复 `invoice_id` 从第二次出现起拒绝，报 `duplicate_id`；有效行按原顺序进入 `records`，被拒行不进入。
- 每条错误为 `{ "line": <原输入行号>, "code": "<错误码>" }`，行号从 2 开始（表头为 1，带引号的多行字段按起始行计）。

错误码全集：`bad_header`、`unclosed_quote`、`bad_amount`、`bad_currency`、`missing_field`、`bad_field_count`、`duplicate_id`。

## 作为库使用

```js
import { importInvoices } from './src/importer.mjs';

const { records, errors } = importInvoices(csvText);
// records: { invoice_id, customer, amount_cents, currency }[]
// errors:  { line, code }[]
```

## 测试

```sh
.runtime/node --test tests/*.test.mjs
```

覆盖：引号内逗号与 `""` 转义、CRLF/末尾换行、精确金额转分与负数/小数位拒绝、重复 ID、坏表头、未闭合引号，以及 CLI 三种退出码。

/**
 * Pure invoice CSV parser.
 *
 * Contract (fixed semantics):
 *  - importInvoices(text) -> { records, errors }
 *  - header (line 1) must be exactly `invoice_id,customer,amount,currency`,
 *    otherwise errors = [{ line: 1, code: 'bad_header' }] and parsing stops.
 *  - records: [{ invoice_id, customer, amount_cents, currency }] in input order.
 *  - errors: [{ line, code }] with `line` = line where the record starts
 *    (header is line 1, data starts at line 2; multi-line quoted fields count
 *    from their starting line).
 *  - Double-quoted fields: commas inside are literal, `""` escapes one `"`.
 *  - Row separators: LF and CRLF. A trailing newline at EOF is allowed.
 *  - Amounts are non-negative decimal strings with no fraction or exactly two
 *    fraction digits, converted to integer cents using string handling only
 *    (no float arithmetic).
 *  - Currency must be CNY or USD.
 *  - Codes: bad_header | unclosed_quote | bad_amount | bad_currency |
 *    missing_field | bad_field_count | duplicate_id.
 *  - A row may contribute several errors.
 */

const HEADER_FIELDS = ['invoice_id', 'customer', 'amount', 'currency'];
const CURRENCIES = new Set(['CNY', 'USD']);
const AMOUNT_RE = /^(\d+)(?:\.(\d{2}))?$/;

/**
 * Convert a non-negative decimal amount string to integer cents.
 * Returns null when the string is not an integer or a 2-decimal number.
 * String-only conversion: '12' -> 1200, '12.34' -> 1234.
 */
function toCents(amount) {
  const match = AMOUNT_RE.exec(amount);
  if (match === null) return null;
  const fraction = match[2] === undefined ? '00' : match[2];
  return Number(`${match[1]}${fraction}`);
}

/**
 * Split CSV text into records, preserving the starting line number and
 * whether a record was cut off by an unclosed quote.
 * @returns {Array<{line: number, fields: string[], unterminated: boolean}>}
 */
function scanRecords(text) {
  const rows = [];
  const length = text.length;
  let index = 0;
  let line = 1;

  while (index < length) {
    const startLine = line;
    const fields = [];
    let unterminated = false;

    for (;;) {
      let value = '';

      if (text[index] === '"') {
        index += 1;
        let closed = false;
        while (index < length) {
          const char = text[index];
          if (char === '"') {
            if (text[index + 1] === '"') {
              value += '"';
              index += 2;
              continue;
            }
            index += 1;
            closed = true;
            break;
          }
          if (char === '\n') {
            line += 1;
            value += char;
            index += 1;
            continue;
          }
          if (char === '\r' && text[index + 1] === '\n') {
            line += 1;
            value += '\r\n';
            index += 2;
            continue;
          }
          value += char;
          index += 1;
        }

        if (!closed) {
          unterminated = true;
        } else {
          // Lenient: characters after the closing quote are kept literally.
          while (
            index < length &&
            text[index] !== ',' &&
            text[index] !== '\n' &&
            !(text[index] === '\r' && text[index + 1] === '\n')
          ) {
            value += text[index];
            index += 1;
          }
        }
      } else {
        while (
          index < length &&
          text[index] !== ',' &&
          text[index] !== '\n' &&
          !(text[index] === '\r' && text[index + 1] === '\n')
        ) {
          value += text[index];
          index += 1;
        }
      }

      fields.push(value);

      if (unterminated) break;
      if (index >= length) break;

      if (text[index] === ',') {
        index += 1;
        continue;
      }

      index += text[index] === '\r' ? 2 : 1;
      line += 1;
      break;
    }

    rows.push({ line: startLine, fields, unterminated });
  }

  return rows;
}

/**
 * Parse a whole invoice CSV document.
 * @param {string} text entire CSV text
 * @returns {{records: Array<{invoice_id: string, customer: string, amount_cents: number, currency: string}>, errors: Array<{line: number, code: string}>}}
 */
export function importInvoices(text) {
  if (typeof text !== 'string') {
    throw new TypeError('importInvoices expects the CSV text as a string');
  }

  const rows = scanRecords(text);
  const records = [];
  const errors = [];

  const header = rows[0];
  if (
    header === undefined ||
    header.unterminated ||
    header.fields.length !== HEADER_FIELDS.length ||
    !HEADER_FIELDS.every((name, i) => header.fields[i] === name)
  ) {
    return { records, errors: [{ line: 1, code: 'bad_header' }] };
  }

  const seenIds = new Set();

  for (let i = 1; i < rows.length; i += 1) {
    const row = rows[i];

    if (row.unterminated) {
      // The quote is never closed, so this record swallows the rest of input.
      errors.push({ line: row.line, code: 'unclosed_quote' });
      break;
    }

    if (row.fields.length !== HEADER_FIELDS.length) {
      errors.push({ line: row.line, code: 'bad_field_count' });
      continue;
    }

    const [invoice_id, customer, amount, currency] = row.fields;
    const rowErrors = [];

    if (invoice_id === '') {
      rowErrors.push({ line: row.line, code: 'missing_field' });
    }
    if (customer === '') {
      rowErrors.push({ line: row.line, code: 'missing_field' });
    }

    const amount_cents = toCents(amount);
    if (amount_cents === null) {
      rowErrors.push({ line: row.line, code: 'bad_amount' });
    }
    if (!CURRENCIES.has(currency)) {
      rowErrors.push({ line: row.line, code: 'bad_currency' });
    }

    if (rowErrors.length > 0) {
      errors.push(...rowErrors);
      continue;
    }

    if (seenIds.has(invoice_id)) {
      errors.push({ line: row.line, code: 'duplicate_id' });
      continue;
    }

    seenIds.add(invoice_id);
    records.push({ invoice_id, customer, amount_cents, currency });
  }

  return { records, errors };
}

#!/usr/bin/env node
import { readFileSync } from 'node:fs';
import { importInvoices } from './importer.mjs';

const file = process.argv[2];

if (file === undefined) {
  process.stderr.write('usage: node src/cli.mjs <invoices.csv>\n');
  process.exit(1);
}

let text;
try {
  text = readFileSync(file, 'utf8');
} catch (err) {
  process.stderr.write(`cannot read ${file}: ${err.message}\n`);
  process.exit(1);
}

const { records, errors } = importInvoices(text);
process.stdout.write(JSON.stringify({ records, errors }) + '\n');
process.exit(errors.length > 0 ? 2 : 0);

# Expense importer

Imports a simple unquoted CSV of expenses and aggregates integer-cent totals per category.

## Usage

```sh
node src/cli.mjs <input.csv>
```

On success prints only the result JSON to stdout and exits `0`:

```json
{"groups":[{"category":"Food","totalCents":123,"count":2}],"totalCents":123,"count":2}
```

## Input format

- First line must be the header `category,amount`.
- Each nonblank data line is an unquoted CSV row with exactly two columns: `category,amount` (e.g. `Food,1.20`).
- One leading BOM is stripped; both LF and CRLF line endings are accepted.
- Blank lines are ignored but still count for line numbering.
- Both fields are trimmed; category must be nonempty.

## Precision

- Amounts are nonnegative decimals with exactly two fractional digits (`/^\d+\.\d\d$/`) — no sign, exponent, or extra decimals.
- Values are converted to exact integer cents. Any single amount, per-category sum, or overall sum outside `Number.MAX_SAFE_INTEGER` is rejected; no floating-point arithmetic is used.

## Errors

On argument, read, or validation failure the CLI prints a concise single-line error to stderr (including the one-based source line number for invalid data; blank lines count in numbering), writes nothing to stdout, and exits `1`. No stack trace is printed.

## Ordering

Groups appear in first-seen category order; totals are exact integer cents.

## Library

```js
import { importExpenses } from './src/importer.mjs';
const result = importExpenses(text); // throws Error with line number on invalid input
```

## Tests

```sh
TMPDIR=.test-tmp .runtime/bin/node .runtime/lib/node_modules/npm/bin/npm-cli.js test
```

const MAX_SAFE_CENTS = BigInt(Number.MAX_SAFE_INTEGER);
const AMOUNT_PATTERN = /^\d+\.\d\d$/;

function parseCents(amount) {
  const dot = amount.indexOf('.');
  return BigInt(amount.slice(0, dot)) * 100n + BigInt(amount.slice(dot + 1));
}

export function importExpenses(text) {
  if (text.charCodeAt(0) === 0xfeff) {
    text = text.slice(1);
  }
  const lines = text.split('\n');
  const header = lines.length > 0 ? lines[0].replace(/\r$/, '') : '';
  if (header !== 'category,amount') {
    throw new Error('line 1: expected header "category,amount"');
  }

  const groups = [];
  const byCategory = new Map();
  let totalCents = 0n;
  let count = 0;

  for (let i = 1; i < lines.length; i++) {
    const lineNo = i + 1;
    const line = lines[i].replace(/\r$/, '');
    if (line.trim() === '') {
      continue;
    }
    const columns = line.split(',');
    if (columns.length !== 2) {
      throw new Error(`line ${lineNo}: expected exactly two columns (category,amount)`);
    }
    const category = columns[0].trim();
    const amount = columns[1].trim();
    if (category === '') {
      throw new Error(`line ${lineNo}: category must be nonempty`);
    }
    if (!AMOUNT_PATTERN.test(amount)) {
      throw new Error(`line ${lineNo}: invalid amount "${amount}" (expected digits with exactly two fractional digits)`);
    }
    const cents = parseCents(amount);
    if (cents > MAX_SAFE_CENTS) {
      throw new Error(`line ${lineNo}: amount exceeds Number.MAX_SAFE_INTEGER cents`);
    }
    let group = byCategory.get(category);
    if (group === undefined) {
      group = {category, totalCents: 0n, count: 0};
      byCategory.set(category, group);
      groups.push(group);
    }
    const groupTotal = group.totalCents + cents;
    if (groupTotal > MAX_SAFE_CENTS) {
      throw new Error(`line ${lineNo}: per-category sum for "${category}" exceeds Number.MAX_SAFE_INTEGER cents`);
    }
    const newTotal = totalCents + cents;
    if (newTotal > MAX_SAFE_CENTS) {
      throw new Error(`line ${lineNo}: overall sum exceeds Number.MAX_SAFE_INTEGER cents`);
    }
    group.totalCents = groupTotal;
    group.count += 1;
    totalCents = newTotal;
    count += 1;
  }

  return {
    groups: groups.map((group) => ({
      category: group.category,
      totalCents: Number(group.totalCents),
      count: group.count,
    })),
    totalCents: Number(totalCents),
    count,
  };
}

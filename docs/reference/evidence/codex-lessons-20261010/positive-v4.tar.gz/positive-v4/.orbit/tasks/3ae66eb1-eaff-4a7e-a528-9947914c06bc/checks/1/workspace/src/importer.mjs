const MAX_SAFE = Number.MAX_SAFE_INTEGER; // 9007199254740991 cents
const MAX_INT_PART = 90071992547409; // Math.floor(MAX_SAFE / 100)
const MAX_FRAC_FOR_MAX_INT = 91; // MAX_SAFE % 100
const AMOUNT_RE = /^(\d+)\.(\d{2})$/;

export function importExpenses(text) {
  if (text.startsWith('﻿')) text = text.slice(1);
  const lines = text.split(/\r?\n/);

  const groups = new Map();
  let totalCents = 0;
  let count = 0;
  let sawHeader = false;

  for (let i = 0; i < lines.length; i++) {
    const lineNo = i + 1; // one-based, blank lines included
    const raw = lines[i];
    if (raw.trim() === '') continue; // blank: ignored for output, counted above

    if (!sawHeader) {
      if (raw !== 'category,amount') {
        throw new Error(`line ${lineNo}: expected header "category,amount"`);
      }
      sawHeader = true;
      continue;
    }

    const cols = raw.split(',');
    if (cols.length !== 2) {
      throw new Error(`line ${lineNo}: expected exactly two columns (category,amount)`);
    }
    const category = cols[0].trim();
    const amountText = cols[1].trim();
    if (category === '') {
      throw new Error(`line ${lineNo}: category must be nonempty`);
    }

    const m = AMOUNT_RE.exec(amountText);
    if (!m) {
      throw new Error(`line ${lineNo}: invalid amount "${amountText}" (need digits with exactly two fraction digits, no sign/exponent)`);
    }
    // Integer arithmetic only: never parseFloat/Number the amount.
    const intDigits = m[1].replace(/^0+/, '') || '0';
    if (intDigits.length > 14) {
      throw new Error(`line ${lineNo}: amount exceeds maximum safe value`);
    }
    const intPart = parseInt(intDigits, 10); // <= 14 digits: exact
    const fracPart = parseInt(m[2], 10); // 0..99
    if (intPart > MAX_INT_PART || (intPart === MAX_INT_PART && fracPart > MAX_FRAC_FOR_MAX_INT)) {
      throw new Error(`line ${lineNo}: amount exceeds maximum safe value`);
    }
    const cents = intPart * 100 + fracPart; // <= MAX_SAFE: exact

    let group = groups.get(category);
    if (group === undefined) {
      group = { category, totalCents: 0, count: 0 };
      groups.set(category, group);
    }
    if (group.totalCents > MAX_SAFE - cents) {
      throw new Error(`line ${lineNo}: category total for "${category}" exceeds maximum safe value`);
    }
    if (totalCents > MAX_SAFE - cents) {
      throw new Error(`line ${lineNo}: overall total exceeds maximum safe value`);
    }
    group.totalCents += cents;
    group.count += 1;
    totalCents += cents;
    count += 1;
  }

  if (!sawHeader) {
    throw new Error('line 1: expected header "category,amount"');
  }

  return { groups: [...groups.values()], totalCents, count };
}

# Expense importer

Imports an unquoted CSV expense file and prints exact integer-cent totals grouped by category.

## Usage

```sh
node src/cli.mjs <input.csv>
```

On success the CLI prints a single JSON object to stdout and exits 0:

```json
{"groups":[{"category":"Food","totalCents":120,"count":1}],"totalCents":120,"count":1}
```

On any failure (wrong argument count, unreadable file, invalid data) it prints a concise
`error: ...` message to stderr, leaves stdout empty, and exits 1. No stack traces.

## Input format

- One header line, exactly `category,amount`.
- Each nonblank data line has exactly two columns: `category,amount`. This is unquoted CSV;
  commas inside fields are not supported.
- A single leading UTF-8 BOM (`﻿`) is stripped. LF and CRLF line endings are accepted.
- Blank lines are ignored for processing but still count toward line numbers in errors.
- Both fields are trimmed. Category must be nonempty after trimming.
- Amount must be nonnegative decimal digits with exactly two fractional digits (`1.20`,
  `0.99`). Signs, exponents, and fewer or more fraction digits are rejected.

## Errors

Invalid input throws/reports an `Error` whose message contains the original one-based line
number (blank lines included): bad header reports line 1, malformed rows report their own
line.

## Ordering and precision

- Groups are returned in first-seen category order.
- Amounts are converted to integer cents with exact string/integer arithmetic — no binary
  floating point is involved, so `0.1 + 0.2` style drift cannot occur.
- Any single amount, per-category sum, or overall sum exceeding `Number.MAX_SAFE_INTEGER`
  cents is rejected with the offending line number.

## Library API

```js
import {importExpenses} from './src/importer.mjs';
const result = importExpenses(text);
// => {groups: [{category, totalCents, count}], totalCents, count}
```

## Tests

```sh
npm test
```

The acceptance suite writes CLI temp input under `os.tmpdir()`; set `TMPDIR` to a writable
directory if needed. No dependencies are required.

// Implement the SPEC command-line interface.

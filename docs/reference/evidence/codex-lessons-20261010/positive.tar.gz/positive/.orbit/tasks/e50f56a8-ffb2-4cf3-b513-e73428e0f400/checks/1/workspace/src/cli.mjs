// Implement the SPEC command-line interface.
import fs from 'node:fs';
import { importExpenses } from './importer.mjs';

const args = process.argv.slice(2);
if (args.length !== 1) {
  console.error('usage: node src/cli.mjs <input.csv>');
  process.exit(1);
}
let text;
try {
  text = fs.readFileSync(args[0], 'utf8');
} catch (err) {
  console.error(`error: cannot read ${args[0]}: ${err.code ?? err.message}`);
  process.exit(1);
}
try {
  console.log(JSON.stringify(importExpenses(text)));
} catch (err) {
  console.error(`error: ${err.message}`);
  process.exit(1);
}

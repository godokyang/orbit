# Expense importer

Reads a CSV of `category,amount` rows, validates it, and prints grouped totals as JSON.

## Usage

```sh
node src/cli.mjs input.csv
```

or `npm test` to run the acceptance suite. No dependencies.

## Input format

- UTF-8 text; one leading BOM (U+FEFF) is stripped.
- LF or CRLF line endings; blank lines are ignored.
- The first line must be the exact header `category,amount`.
- Unquoted CSV: each data line must have exactly two columns; both fields are trimmed.
- `category` must be nonempty after trimming.
- `amount` must be a nonnegative decimal with exactly two fractional digits (no sign, no exponent, no extra decimals), e.g. `1.20`, `0.99`. `1`, `1.0`, `1e2`, `-1.00` are rejected.

## Output

On success, only the result JSON goes to stdout (exit 0):

```json
{"groups":[{"category":"Food","totalCents":122,"count":2}],"totalCents":122,"count":2}
```

- Amounts are converted to exact integer cents (no floating-point accumulation).
- `groups` preserves first-seen category order; each entry is `{category,totalCents,count}`.
- `totalCents`/`count` are overall sums.

## Errors and limits

- Invalid data, unreadable file, or wrong argument count: concise message on stderr, empty stdout, exit 1. No stack trace.
- Error messages include the original 1-based line number (blank lines still count).
- A single amount, a per-category sum, or the overall sum exceeding `Number.MAX_SAFE_INTEGER` (2^53−1) is rejected.

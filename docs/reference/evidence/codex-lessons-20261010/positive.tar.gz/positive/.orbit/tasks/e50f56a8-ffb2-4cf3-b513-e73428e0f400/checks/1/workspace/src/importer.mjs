// Implement the SPEC importer.
const MAX_SAFE = Number.MAX_SAFE_INTEGER;

function parseCents(raw, line) {
  const value = raw.trim();
  if (!/^(0|[1-9]\d*)\.\d{2}$/.test(value)) {
    throw new Error(`line ${line}: invalid amount "${value}"`);
  }
  const [intPart, fracPart] = value.split('.');
  const cents = Number(intPart) * 100 + Number(fracPart);
  if (!Number.isSafeInteger(cents)) {
    throw new Error(`line ${line}: amount exceeds safe integer range`);
  }
  return cents;
}

function checkSafe(value, what, line) {
  if (value > MAX_SAFE) {
    throw new Error(`line ${line}: ${what} sum exceeds safe integer range`);
  }
}

export function importExpenses(text) {
  if (text.startsWith('\ufeff')) text = text.slice(1);
  const lines = text.split(/\r?\n/);
  if ((lines[0] ?? '').trim() !== 'category,amount') {
    throw new Error('line 1: expected header "category,amount"');
  }
  const byCategory = new Map();
  let totalCents = 0;
  let count = 0;
  for (let i = 1; i < lines.length; i++) {
    const lineNo = i + 1;
    const line = lines[i];
    if (line.trim() === '') continue;
    const cols = line.split(',');
    if (cols.length !== 2) {
      throw new Error(`line ${lineNo}: expected exactly two columns`);
    }
    const category = cols[0].trim();
    if (category === '') {
      throw new Error(`line ${lineNo}: category must be nonempty`);
    }
    const cents = parseCents(cols[1], lineNo);
    const group = byCategory.get(category);
    if (group) {
      checkSafe(group.totalCents + cents, `category "${category}"`, lineNo);
      group.totalCents += cents;
      group.count += 1;
    } else {
      byCategory.set(category, { category, totalCents: cents, count: 1 });
    }
    checkSafe(totalCents + cents, 'overall', lineNo);
    totalCents += cents;
    count += 1;
  }
  return { groups: [...byCategory.values()], totalCents, count };
}

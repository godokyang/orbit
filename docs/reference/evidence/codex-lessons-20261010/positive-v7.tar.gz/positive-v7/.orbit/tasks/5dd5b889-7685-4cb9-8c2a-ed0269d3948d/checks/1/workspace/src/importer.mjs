const AMOUNT_RE = /^[0-9]+\.[0-9]{2}$/;
const MAX = Number.MAX_SAFE_INTEGER;

// Parse "DDD.DD" into exact integer cents using only digit strings.
// Throws (via fail) with the 1-based line number when over MAX_SAFE_INTEGER.
function parseCents(amount, lineNo) {
  const dot = amount.indexOf('.');
  let intPart = amount.slice(0, dot).replace(/^0+/, '');
  const fracPart = amount.slice(dot + 1);
  // MAX cents = 9007199254740991 (16 digits), so the integer part can be
  // at most 14 significant digits before * 100 overflows the safe range.
  if (intPart.length > 14) {
    throw new Error(`line ${lineNo}: amount exceeds maximum safe value`);
  }
  const cents = (intPart === '' ? 0 : Number(intPart)) * 100 + Number(fracPart);
  if (cents > MAX) {
    throw new Error(`line ${lineNo}: amount exceeds maximum safe value`);
  }
  return cents;
}

export function importExpenses(text) {
  if (text.startsWith('\ufeff')) text = text.slice(1);
  const rawLines = text.split('\n');

  const header = rawLines.length > 0 ? rawLines[0].replace(/\r$/, '') : '';
  if (header !== 'category,amount') {
    throw new Error("line 1: expected header 'category,amount'");
  }

  const groups = [];
  const byCategory = new Map();
  let totalCents = 0;
  let count = 0;

  for (let i = 1; i < rawLines.length; i++) {
    const lineNo = i + 1; // 1-based, counting all lines including blanks
    const line = rawLines[i].replace(/\r$/, ''); // tolerate CRLF
    if (line.trim() === '') continue; // blank lines ignored, numbering kept

    const cols = line.split(',');
    if (cols.length !== 2) {
      throw new Error(`line ${lineNo}: expected exactly 2 columns`);
    }
    const category = cols[0].trim();
    const amount = cols[1].trim();
    if (category === '') {
      throw new Error(`line ${lineNo}: category must be nonempty`);
    }
    if (!AMOUNT_RE.test(amount)) {
      throw new Error(`line ${lineNo}: invalid amount '${amount}'`);
    }

    const cents = parseCents(amount, lineNo);

    let group = byCategory.get(category);
    if (group === undefined) {
      group = { category, totalCents: 0, count: 0 };
      byCategory.set(category, group);
      groups.push(group); // preserves first-seen category order
    }
    const groupTotal = group.totalCents + cents;
    if (groupTotal > MAX) {
      throw new Error(`line ${lineNo}: category total exceeds maximum safe value`);
    }
    const newTotal = totalCents + cents;
    if (newTotal > MAX) {
      throw new Error(`line ${lineNo}: overall total exceeds maximum safe value`);
    }
    group.totalCents = groupTotal;
    group.count += 1;
    totalCents = newTotal;
    count += 1;
  }

  return { groups, totalCents, count };
}

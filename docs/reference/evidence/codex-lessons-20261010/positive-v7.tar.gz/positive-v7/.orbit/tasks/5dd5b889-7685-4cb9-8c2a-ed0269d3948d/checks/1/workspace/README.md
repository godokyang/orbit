# expense-importer

CSV 费用导入工具：读取 `category,amount` 格式的 CSV，按类别汇总为精确的整数分（cents），输出 JSON。

## 用法

```sh
node src/cli.mjs <input.csv>
```

- 恰好接受一个路径参数；文件按 UTF-8 读取。
- 成功时仅向 stdout 输出结果 JSON，退出码 0：

```json
{"groups":[{"category":"Food","totalCents":123,"count":2}],"totalCents":123,"count":2}
```

- 失败（参数错误、文件不可读、数据校验失败）时向 stderr 输出一行简洁错误，stdout 为空，退出码 1，无堆栈信息。

## 输入格式

- 首行必须为表头 `category,amount`（自动去除一个前导 BOM）。
- 支持 LF 或 CRLF 换行；空行被忽略，但仍参与 1-based 行号计数。
- 非引号 CSV：每个数据行必须恰好两列；两字段均做首尾空白 trim。
- 类别必须非空。
- 金额必须是非负十进制数且恰好两位小数（无符号、无指数、无多余小数位），如 `1.20`、`0.99`。

## 精度与溢出

- 金额以整数分精确计算，全程不使用浮点累加。
- 单个金额、单类别合计或总合计超过 `Number.MAX_SAFE_INTEGER`（9007199254740991）时拒绝并报错。

## 错误与行号

- 任何无效数据（含表头错误、列数不符、空类别、金额格式非法、溢出）抛出 `Error`，消息包含原始 1-based 行号（空行也计入行号）。
- CLI 将该错误信息原样输出到 stderr 并以退出码 1 结束。

## 排序

- `groups` 保持类别首次出现顺序；`totalCents` 与 `count` 为对应合计。

## 测试

```sh
npm test
```

无需任何外部依赖、网络或提交/推送操作。

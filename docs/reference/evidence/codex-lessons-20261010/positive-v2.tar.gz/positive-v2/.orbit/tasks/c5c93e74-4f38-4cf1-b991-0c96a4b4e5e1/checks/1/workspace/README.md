# Expense importer

Imports a CSV of expenses (`category,amount`), groups amounts by category in integer
cents, and prints the totals as JSON. Zero dependencies; pure Node.js.

## Usage

```sh
node src/cli.mjs <input.csv>
```

- Exactly one path argument is accepted. The file is read as UTF-8.
- On success the result JSON is printed to stdout and the exit code is `0`:

```json
{"groups":[{"category":"Food","totalCents":122,"count":2}],"totalCents":122,"count":2}
```

## Input format

- First line must be the header `category,amount`.
- Each data line is `category,amount`. This is unquoted CSV: exactly two columns per
  nonblank line, no quoting/escaping.
- One leading BOM is stripped; both LF and CRLF line endings are accepted; blank
  lines are ignored.
- Both fields are trimmed. The category must be nonempty.
- The amount must be a nonnegative decimal with exactly two fractional digits:
  no sign, no exponent, no extra or missing decimals (e.g. `1.20`, `0.99`; not
  `-1.00`, `1`, `1.0`, `1.001`, `1e2`).
- Amounts are converted to integer cents with exact integer arithmetic — no float
  math, no precision loss.

## Errors

Any argument, read, or validation failure prints a single concise error line to
stderr (no stack trace), writes nothing to stdout, and exits with code `1`.
Validation errors include the one-based line number of the offending line; blank
lines count toward numbering (the header is line 1). Amounts or accumulated
per-category / overall sums beyond `Number.MAX_SAFE_INTEGER` are rejected as
overflow at the offending line.

## Ordering and precision

- Categories appear in `groups` in first-seen order.
- All totals are integer cents (`totalCents`), exact for any value the input format
  can express within the safe-integer limit.

## Library use

```js
import { importExpenses } from './src/importer.mjs';

const result = importExpenses('category,amount\nFood,1.20\n');
// { groups: [{ category: 'Food', totalCents: 120, count: 1 }], totalCents: 120, count: 1 }
```

`importExpenses(text)` throws `Error` (with the one-based line number in the
message) on invalid data, and returns the same shape the CLI prints.

## Tests

```sh
npm test
```

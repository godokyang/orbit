// CSV expense importer: category,amount rows with a required `category,amount` header.
// Zero dependencies, pure function, exact integer-cent arithmetic.

const HEADER = 'category,amount';
const AMOUNT_RE = /^\d+\.\d{2}$/;
// Largest value whose cents representation is still a safe integer.
const MAX_SAFE = Number.MAX_SAFE_INTEGER;

// Any integer part with 15+ significant digits is >= 10^14, and 10^14 * 100 = 10^16
// exceeds Number.MAX_SAFE_INTEGER, so it is always an overflow and would also lose
// precision as a double. Keeping the bound at 14 digits guarantees Number() is exact.
const MAX_INT_DIGITS = 14;

function parseCents(raw, line) {
  if (!AMOUNT_RE.test(raw)) {
    throw new Error(
      `Invalid amount "${raw}" at line ${line}: expected nonnegative digits with exactly two decimals`,
    );
  }
  const dot = raw.indexOf('.');
  const intPart = raw.slice(0, dot);
  const fracPart = raw.slice(dot + 1);
  if (intPart.replace(/^0+/, '').length > MAX_INT_DIGITS) {
    throw new Error(`Amount "${raw}" at line ${line} exceeds Number.MAX_SAFE_INTEGER`);
  }
  const cents = Number(intPart) * 100 + Number(fracPart);
  if (!Number.isSafeInteger(cents)) {
    throw new Error(`Amount "${raw}" at line ${line} exceeds Number.MAX_SAFE_INTEGER`);
  }
  return cents;
}

export function importExpenses(text) {
  const source = text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;
  const lines = source.split(/\r\n|\n|\r/);

  if (lines[0].trim() !== HEADER) {
    throw new Error(`Invalid header at line 1: expected "${HEADER}"`);
  }

  const byCategory = new Map();
  let totalCents = 0;
  let count = 0;

  for (let i = 1; i < lines.length; i++) {
    const line = i + 1; // one-based, blank lines included
    const raw = lines[i];
    if (raw.trim() === '') continue;

    const columns = raw.split(',');
    if (columns.length !== 2) {
      throw new Error(`Expected exactly 2 columns at line ${line}`);
    }

    const category = columns[0].trim();
    if (category === '') {
      throw new Error(`Empty category at line ${line}`);
    }

    const cents = parseCents(columns[1].trim(), line);

    const group = byCategory.get(category);
    const groupTotal = (group ? group.totalCents : 0) + cents;
    if (!Number.isSafeInteger(groupTotal)) {
      throw new Error(`Category total exceeds Number.MAX_SAFE_INTEGER at line ${line}`);
    }

    const nextTotal = totalCents + cents;
    if (!Number.isSafeInteger(nextTotal)) {
      throw new Error(`Total exceeds Number.MAX_SAFE_INTEGER at line ${line}`);
    }

    if (group) {
      group.totalCents = groupTotal;
      group.count += 1;
    } else {
      byCategory.set(category, {category, totalCents: groupTotal, count: 1});
    }
    totalCents = nextTotal;
    count += 1;
  }

  return {groups: [...byCategory.values()], totalCents, count};
}

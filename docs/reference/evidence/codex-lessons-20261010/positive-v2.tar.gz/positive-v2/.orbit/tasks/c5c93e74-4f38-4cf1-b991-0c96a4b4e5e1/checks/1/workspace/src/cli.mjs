import { readFileSync } from 'node:fs';
import { importExpenses } from './importer.mjs';

function fail(message) {
  console.error(`error: ${message}`);
  process.exit(1);
}

const args = process.argv.slice(2);
if (args.length !== 1) {
  fail('expected exactly one argument: node src/cli.mjs <input.csv>');
}

let text;
try {
  text = readFileSync(args[0], 'utf8');
} catch (err) {
  fail(`cannot read "${args[0]}": ${err.code ?? err.message}`);
}

let result;
try {
  result = importExpenses(text);
} catch (err) {
  fail(err.message);
}

console.log(JSON.stringify(result));

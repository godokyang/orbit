import { readFileSync } from 'node:fs';
import { importExpenses } from './importer.mjs';

const args = process.argv.slice(2);
if (args.length !== 1) {
  console.error('usage: node src/cli.mjs <file.csv>');
  process.exit(1);
}
try {
  const text = readFileSync(args[0], 'utf8');
  process.stdout.write(JSON.stringify(importExpenses(text)) + '\n');
} catch (err) {
  console.error(`error: ${err.message}`);
  process.exit(1);
}

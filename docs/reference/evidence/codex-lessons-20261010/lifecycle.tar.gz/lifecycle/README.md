# Expense importer

CSV expense import per `SPEC.md`: parse `category,amount` lines, group by category in
first-seen order, and sum amounts as exact integer cents.

## Invocation

```sh
node src/cli.mjs <file.csv>
```

Reads exactly one path argument, decoded as UTF-8. On success the result JSON is the
only stdout output and the exit code is `0`:

```json
{"groups":[{"category":"Food","totalCents":123,"count":2}],"totalCents":123,"count":2}
```

A file containing only the `category,amount` header (empty CSV) is valid and yields
`{"groups":[],"totalCents":0,"count":0}` with exit code `0`.

## Input format

- The first line must be the exact header `category,amount`.
- One leading BOM is stripped; both LF and CRLF line endings are accepted.
- Blank lines are ignored.
- Unquoted CSV: each data line must have exactly two columns; both fields are trimmed;
  the category must be nonempty.
- The amount must be nonnegative decimal digits with exactly two fractional digits —
  no sign, exponent, or extra decimals (e.g. `1.20` is valid; `-1.00`, `1`, `1.0`,
  `1.001`, `1e2` are not).

## Errors

Any argument, read, or validation failure prints a concise one-line error to stderr,
writes nothing to stdout, and exits with code `1`. Validation errors include the
original one-based line number (blank lines are counted in the numbering). No stack
trace is printed.

## Precision

Cents are computed as exact integers (never via floating-point multiplication).
A single amount, a per-category sum, or the overall sum exceeding
`Number.MAX_SAFE_INTEGER` is rejected with a validation error (exit `1`).

## Ordering

Groups are emitted in first-seen category order; `totalCents` and `count` are overall
totals across all data rows.

## Development

No dependencies. Run the acceptance suite with the bundled runtime:

```sh
.runtime/bin/node tests/acceptance.mjs
```

(The bundled `.runtime/bin/npm` does not work under `type: module`; invoke
`.runtime/bin/node` directly.)

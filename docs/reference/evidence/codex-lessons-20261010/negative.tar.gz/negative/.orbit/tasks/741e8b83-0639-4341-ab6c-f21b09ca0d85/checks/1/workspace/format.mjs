export const label = value => `item:${value.trim()}`;

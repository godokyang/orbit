import assert from "node:assert/strict"; import {label} from "./format.mjs"; assert.equal(label(" book "), "item:book"); console.log("PASS label trim");

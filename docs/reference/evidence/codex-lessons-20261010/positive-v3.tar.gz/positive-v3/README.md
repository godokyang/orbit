# Expense importer

Zero-dependency Node.js tool that sums expense CSV files into integer-cent totals per category.

## Usage

```sh
node src/cli.mjs <input.csv>
```

or, with npm:

```sh
npm test          # runs the acceptance suite in tests/acceptance.mjs
```

On success the CLI prints exactly one JSON object to stdout and exits `0`:

```json
{"groups":[{"category":"Food","totalCents":122,"count":2}],"totalCents":122,"count":2}
```

- `groups` — one entry per category, in first-seen order.
- `totalCents` / `count` — overall sum in integer cents and total data-line count.

On failure the CLI prints a concise `error: ...` message to stderr, writes nothing to stdout, and exits `1`.

## Input format

- First line must be the exact header `category,amount`.
- Data lines are `category,amount` — unquoted CSV, exactly two columns.
- Both fields are trimmed; category must be nonempty.
- Amount is a nonnegative decimal with exactly two fractional digits (e.g. `1.20`, `0.05`). Signs, exponents, missing or extra decimals are rejected.
- The file is read as UTF-8; one leading BOM is stripped. Both LF and CRLF line endings work; blank lines are ignored.
- Invalid lines are reported with their original one-based line number (blank lines still count).

## Precision

Amounts are converted to integer cents via exact integer arithmetic on the digit substrings — no floating-point parsing. Any single amount, per-category sum, or overall sum that would exceed `Number.MAX_SAFE_INTEGER` (9007199254740991 cents) is rejected with the offending line number.

## Error cases (exit 1, message on stderr)

| Cause | Example |
| --- | --- |
| Wrong number of arguments | `node src/cli.mjs` or two paths |
| Unreadable file | missing path, permission denied |
| Invalid header | `type,amount` → line 1 |
| Wrong column count | `A,1.00,x` → that line number |
| Empty category | ` ,1.00` → that line number |
| Malformed amount | `1`, `1.0`, `-1.00`, `1e2`, `1.001` → that line number |
| Sum/amount overflow | totals beyond `Number.MAX_SAFE_INTEGER` → that line number |

Errors never print a stack trace.

## Layout

- `src/importer.mjs` — pure `importExpenses(text)` function (no I/O).
- `src/cli.mjs` — argument handling, file reading, JSON output.
- `tests/acceptance.mjs` — acceptance suite (`npm test`).

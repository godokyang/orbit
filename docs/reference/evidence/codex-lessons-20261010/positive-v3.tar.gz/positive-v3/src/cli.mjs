import { readFileSync } from 'node:fs';
import { importExpenses } from './importer.mjs';

function fail(message) {
  process.stderr.write(`error: ${message}\n`);
  process.exit(1);
}

const [path] = process.argv.slice(2);
if (!path) fail('exactly one input file path is required');
if (process.argv.length > 3) fail('exactly one input file path is required');

let text;
try {
  text = readFileSync(path, 'utf8');
} catch (err) {
  fail(`cannot read '${path}': ${err.code ?? err.message}`);
}

let result;
try {
  result = importExpenses(text);
} catch (err) {
  fail(err.message);
}

process.stdout.write(`${JSON.stringify(result)}\n`);

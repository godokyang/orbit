const HEADER = 'category,amount';
const AMOUNT_PATTERN = /^\d+\.\d\d$/;
const MAX_SAFE_CENTS = BigInt(Number.MAX_SAFE_INTEGER);

export function importExpenses(text) {
  let source = String(text);
  // Strip at most one leading UTF-8 BOM.
  if (source.charCodeAt(0) === 0xfeff) source = source.slice(1);

  const lines = source.split(/\r\n|\n/);

  if (lines[0] !== HEADER) {
    throw new Error(`Invalid header on line 1: expected "${HEADER}"`);
  }

  const groups = new Map();
  let totalCents = 0n;
  let count = 0;

  for (let i = 1; i < lines.length; i++) {
    const raw = lines[i];
    const lineNumber = i + 1; // blank lines keep their place in the numbering
    if (raw.trim() === '') continue;

    const columns = raw.split(',');
    if (columns.length !== 2) {
      throw new Error(`Invalid record on line ${lineNumber}: expected exactly two columns`);
    }

    const category = columns[0].trim();
    const amount = columns[1].trim();

    if (category === '') {
      throw new Error(`Invalid record on line ${lineNumber}: category is empty`);
    }
    if (!AMOUNT_PATTERN.test(amount)) {
      throw new Error(`Invalid amount on line ${lineNumber}: "${amount}"`);
    }

    const [intPart, fracPart] = amount.split('.');
    const cents = BigInt(intPart) * 100n + BigInt(fracPart);
    if (cents > MAX_SAFE_CENTS) {
      throw new Error(`Amount on line ${lineNumber} exceeds Number.MAX_SAFE_INTEGER cents`);
    }

    const group = groups.get(category);
    const nextGroupTotal = (group ? group.totalCents : 0n) + cents;
    if (nextGroupTotal > MAX_SAFE_CENTS) {
      throw new Error(`Total for category "${category}" on line ${lineNumber} exceeds Number.MAX_SAFE_INTEGER cents`);
    }

    const nextTotal = totalCents + cents;
    if (nextTotal > MAX_SAFE_CENTS) {
      throw new Error(`Overall total on line ${lineNumber} exceeds Number.MAX_SAFE_INTEGER cents`);
    }

    if (group) {
      group.totalCents = nextGroupTotal;
      group.count += 1;
    } else {
      groups.set(category, {category, totalCents: nextGroupTotal, count: 1});
    }
    totalCents = nextTotal;
    count += 1;
  }

  return {
    groups: [...groups.values()].map((group) => ({
      category: group.category,
      totalCents: Number(group.totalCents),
      count: group.count,
    })),
    totalCents: Number(totalCents),
    count,
  };
}

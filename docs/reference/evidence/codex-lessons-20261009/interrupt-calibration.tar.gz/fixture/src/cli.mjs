#!/usr/bin/env node
import fs from 'node:fs';
import {importExpenses} from './importer.mjs';

function fail(message) {
  process.stderr.write(`Error: ${message}\n`);
  process.exit(1);
}

const args = process.argv.slice(2);
if (args.length !== 1) {
  fail('usage: node src/cli.mjs <csv-file>');
}

let text;
try {
  text = fs.readFileSync(args[0], 'utf8');
} catch {
  fail(`cannot read file: ${args[0]}`);
}

let result;
try {
  result = importExpenses(text);
} catch (err) {
  fail(err.message);
}

process.stdout.write(JSON.stringify(result) + '\n');

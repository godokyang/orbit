#!/usr/bin/env node
import fs from 'node:fs';
import { importExpenses } from './importer.mjs';

function die(message) {
  process.stderr.write(`error: ${message}\n`);
  process.exit(1);
}

const args = process.argv.slice(2);
if (args.length !== 1) die('usage: node src/cli.mjs <csv-file>');

let text;
try {
  text = fs.readFileSync(args[0], 'utf8');
} catch (err) {
  die(`cannot read ${args[0]}: ${err.code ?? err.message}`);
}

try {
  process.stdout.write(JSON.stringify(importExpenses(text)) + '\n');
} catch (err) {
  die(err.message);
}

# CSV Expense Summarizer

Reads an unquoted CSV expense file and prints a JSON summary of per-category totals in exact integer cents.

## Usage

```sh
node src/cli.mjs <csv-file>
```

- Exactly one path argument, read as UTF-8.
- On success: only the result JSON on stdout, exit code 0.
- On argument, read, or validation failure: a concise `error: ...` message on stderr, empty stdout, exit code 1. No stack traces.

Run the acceptance suite with `npm test`. No dependencies.

## Input format

- Required header line: `category,amount`.
- One optional leading BOM is stripped; LF and CRLF line endings are accepted.
- Blank lines are ignored for parsing but still count toward one-based line numbers in error messages.
- Each nonblank data line must have exactly two comma-separated columns; both fields are trimmed. Category must be nonempty.
- Amount must be a nonnegative decimal with exactly two fractional digits (`^\d+\.\d{2}$`); no sign, exponent, or extra decimals.

## Output

```json
{"groups":[{"category":"Food","totalCents":123,"count":2}],"totalCents":123,"count":2}
```

- `groups` preserves first-seen category order.
- All totals are integer cents computed exactly (no floating point).

## Errors and precision

Any invalid input throws an `Error` whose message contains the original one-based line number, including blank lines in the numbering. A single amount whose cents exceed `Number.MAX_SAFE_INTEGER`, or a per-category or overall sum exceeding it, is rejected at the offending line.

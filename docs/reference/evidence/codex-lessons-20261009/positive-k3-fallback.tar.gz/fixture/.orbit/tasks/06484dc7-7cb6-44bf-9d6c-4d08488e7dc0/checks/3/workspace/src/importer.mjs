const MAX = BigInt(Number.MAX_SAFE_INTEGER);
const AMOUNT_RE = /^\d+\.\d{2}$/;

function fail(line, message) {
  throw new Error(`line ${line}: ${message}`);
}

function toCents(amount, line) {
  if (!AMOUNT_RE.test(amount)) fail(line, `invalid amount ${JSON.stringify(amount)}`);
  const [intPart, fracPart] = amount.split('.');
  const cents = BigInt(intPart) * 100n + BigInt(fracPart);
  if (cents > MAX) fail(line, `amount ${amount} exceeds maximum safe integer cents`);
  return cents;
}
export function importExpenses(text) {
  if (text.startsWith('﻿')) text = text.slice(1);
  const lines = text.split(/\r\n|\n/);
  // A trailing newline produces a final empty segment; it is a blank line,
  // which is ignored for parsing but still counts for line numbering.
  if (lines.length === 0 || lines[0].trim() !== 'category,amount') {
    fail(1, 'missing or invalid header, expected "category,amount"');
  }
  const groups = new Map();
  let totalCents = 0;
  let count = 0;
  for (let i = 1; i < lines.length; i++) {
    const lineNo = i + 1;
    const raw = lines[i];
    if (raw.trim() === '') continue;
    const cols = raw.split(',');
    if (cols.length !== 2) fail(lineNo, `expected exactly two columns, got ${cols.length}`);
    const category = cols[0].trim();
    const amount = cols[1].trim();
    if (category === '') fail(lineNo, 'category must be nonempty');
    const cents = toCents(amount, lineNo);
    const group = groups.get(category) ?? { category, totalCents: 0, count: 0 };
    const newGroupTotal = BigInt(group.totalCents) + cents;
    const newTotal = BigInt(totalCents) + cents;
    if (newGroupTotal > MAX) fail(lineNo, `category ${JSON.stringify(category)} sum exceeds maximum safe integer cents`);
    if (newTotal > MAX) fail(lineNo, 'overall sum exceeds maximum safe integer cents');
    group.totalCents = Number(newGroupTotal);
    group.count += 1;
    groups.set(category, group);
    totalCents = Number(newTotal);
    count += 1;
  }
  return { groups: [...groups.values()], totalCents, count };
}

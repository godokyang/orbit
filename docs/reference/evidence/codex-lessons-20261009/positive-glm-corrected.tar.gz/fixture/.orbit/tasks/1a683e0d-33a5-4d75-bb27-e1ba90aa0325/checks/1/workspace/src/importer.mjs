const HEADER = 'category,amount';
const AMOUNT_PATTERN = /^[0-9]+\.[0-9]{2}$/;
const MAX_SAFE_CENTS = BigInt(Number.MAX_SAFE_INTEGER);

/**
 * Parse unquoted `category,amount` CSV text into integer-cent totals.
 *
 * @param {string} text
 * @returns {{groups: Array<{category: string, totalCents: number, count: number}>, totalCents: number, count: number}}
 */
export function importExpenses(text) {
  if (typeof text !== 'string') {
    throw new TypeError('importExpenses expects a string');
  }

  // Strip exactly one leading BOM; it belongs to line 1 for numbering purposes.
  const body = text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;
  const lines = body.split(/\r\n|\n/);

  if (lines[0] !== HEADER) {
    throw new Error(`Line 1: expected header "${HEADER}"`);
  }

  const groups = new Map();
  let totalCents = 0n;
  let count = 0;

  for (let index = 1; index < lines.length; index++) {
    const line = lines[index];
    if (line.trim() === '') continue;

    const lineNumber = index + 1;
    const columns = line.split(',');
    if (columns.length !== 2) {
      throw new Error(`Line ${lineNumber}: expected exactly two columns`);
    }

    const category = columns[0].trim();
    const amount = columns[1].trim();

    if (category === '') {
      throw new Error(`Line ${lineNumber}: category must not be empty`);
    }
    if (!AMOUNT_PATTERN.test(amount)) {
      throw new Error(`Line ${lineNumber}: invalid amount "${amount}"`);
    }

    const [whole, fraction] = amount.split('.');
    const cents = BigInt(whole) * 100n + BigInt(fraction);
    if (cents > MAX_SAFE_CENTS) {
      throw new Error(`Line ${lineNumber}: amount exceeds Number.MAX_SAFE_INTEGER`);
    }

    const group = groups.get(category);
    const groupCents = (group ? group.totalCents : 0n) + cents;
    const nextTotalCents = totalCents + cents;
    if (groupCents > MAX_SAFE_CENTS || nextTotalCents > MAX_SAFE_CENTS) {
      throw new Error(`Line ${lineNumber}: total exceeds Number.MAX_SAFE_INTEGER`);
    }

    if (group) {
      group.totalCents = groupCents;
      group.count += 1;
    } else {
      groups.set(category, {category, totalCents: groupCents, count: 1});
    }
    totalCents = nextTotalCents;
    count += 1;
  }

  return {
    groups: [...groups.values()].map((group) => ({
      category: group.category,
      totalCents: Number(group.totalCents),
      count: group.count,
    })),
    totalCents: Number(totalCents),
    count,
  };
}

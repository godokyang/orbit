# CSV expense summarizer

Sums `category,amount` CSV files into exact integer-cent totals.

## Usage

```sh
node src/cli.mjs input.csv
```

Exactly one path argument is required; the file is read as UTF-8. On success the summary JSON is printed to stdout and the exit code is 0:

```json
{"groups":[{"category":"Food","totalCents":309,"count":2}],"totalCents":309,"count":3}
```

`groups` preserves first-seen category order; each entry carries `category`, exact `totalCents` and row `count`; `totalCents`/`count` cover all rows.

## Input format

- First line must be the header `category,amount` (a single leading BOM is stripped).
- Each nonblank data line has exactly two columns: a nonempty category and a nonnegative amount with exactly two fractional digits (e.g. `1.20`); no signs, exponents, or extra decimals. Both fields are trimmed. Unquoted CSV only.
- LF or CRLF line endings; blank lines are ignored.

## Errors

Invalid input (wrong header, wrong column count, empty category, malformed amount, or any value/per-category/overall sum exceeding `Number.MAX_SAFE_INTEGER`) produces a concise error on stderr that includes the original one-based line number, empty stdout, and exit code 1. Missing or unreadable files, and wrong argument counts, also exit 1 with an error on stderr. No stack traces are printed.

## Library

`importExpenses(text)` in `src/importer.mjs` implements the same rules and returns the summary object, throwing `Error` with the offending line number.

Run the acceptance suite with `npm test`.

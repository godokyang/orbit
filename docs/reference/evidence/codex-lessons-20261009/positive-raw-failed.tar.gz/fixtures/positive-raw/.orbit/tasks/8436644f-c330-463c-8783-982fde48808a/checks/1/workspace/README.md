# CSV Expense Summarizer

Summarizes a `category,amount` CSV file into exact integer-cent totals, grouped by category in first-seen order.

## Invocation

```sh
node src/cli.mjs <file.csv>
```

Exactly one path argument is required. The file is read as UTF-8.

## Input format

- First line must be the header `category,amount`.
- Data lines are unquoted CSV with exactly two columns: category and amount.
- One leading BOM is stripped; LF and CRLF line endings are accepted; blank lines are ignored.
- Both fields are trimmed; the category must be nonempty.
- Amounts are nonnegative decimals with exactly two fractional digits (`123.45`); no sign, exponent, or extra decimals.
- Sums are computed in integer cents and never lose precision.

## Output

On success the result JSON is printed to stdout and the exit code is 0:

```json
{"groups":[{"category":"Food","totalCents":121,"count":2},{"category":"Travel","totalCents":99,"count":1}],"totalCents":220,"count":3}
```

Groups appear in first-seen category order. `totalCents` is the exact overall total; `count` is the number of data rows.

## Errors

On argument, file-read, or validation failures nothing is written to stdout; a concise error message (including the original one-based line number of the offending input line, blank lines counted) is written to stderr and the exit code is 1. No stack trace is printed.

## Importer API

```js
import { importExpenses } from './src/importer.mjs';
importExpenses(text); // → {groups:[{category,totalCents,count}],totalCents,count}; throws Error with the line number on invalid data
```

## Tests

```sh
npm test
```

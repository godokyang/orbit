import { importExpenses } from './importer.mjs';
import fs from 'node:fs';

function fail(message) {
  console.error(message);
  process.exit(1);
}

const [file] = process.argv.slice(2);
if (!file || process.argv.length !== 3) {
  fail('Usage: node src/cli.mjs <file.csv>');
}

let text;
try {
  text = fs.readFileSync(file, 'utf8');
} catch (err) {
  fail(`Cannot read file: ${file}`);
}

let result;
try {
  result = importExpenses(text);
} catch (err) {
  fail(`Invalid input: ${err.message}`);
}

console.log(JSON.stringify(result));

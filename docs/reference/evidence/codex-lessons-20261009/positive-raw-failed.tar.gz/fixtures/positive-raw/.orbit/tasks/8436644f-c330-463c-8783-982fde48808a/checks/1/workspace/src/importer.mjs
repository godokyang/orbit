const HEADER = 'category,amount';
const AMOUNT_RE = /^\d+\.\d{2}$/;
const MAX_SAFE = BigInt(Number.MAX_SAFE_INTEGER);

export function importExpenses(text) {
  if (typeof text !== 'string') {
    throw new Error('Invalid input: expected a string at line 1');
  }

  // Strip exactly one leading BOM.
  const body = text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;

  // Accept LF or CRLF: split on LF, drop a single trailing CR per line.
  const lines = body.split('\n').map((line) =>
    line.endsWith('\r') ? line.slice(0, -1) : line
  );

  if (lines.length === 0 || lines[0].trim() !== HEADER) {
    throw new Error(
      `Invalid header at line 1: expected "${HEADER}"`
    );
  }

  const groups = [];
  const byCategory = new Map();
  let totalCents = 0n;
  let count = 0;

  for (let i = 1; i < lines.length; i++) {
    const lineNo = i + 1;
    const raw = lines[i];

    if (raw.trim() === '') continue;

    const columns = raw.split(',');
    if (columns.length !== 2) {
      throw new Error(
        `Invalid row at line ${lineNo}: expected exactly two columns`
      );
    }

    const category = columns[0].trim();
    const amount = columns[1].trim();

    if (category === '') {
      throw new Error(`Invalid row at line ${lineNo}: empty category`);
    }

    if (!AMOUNT_RE.test(amount)) {
      throw new Error(`Invalid row at line ${lineNo}: invalid amount "${amount}"`);
    }

    // Exact integer math, no floating point.
    const [intPart, fracPart] = amount.split('.');
    const cents = BigInt(intPart) * 100n + BigInt(fracPart);

    if (cents > MAX_SAFE) {
      throw new Error(
        `Amount at line ${lineNo} exceeds Number.MAX_SAFE_INTEGER`
      );
    }

    const group = byCategory.get(category);
    const nextGroupTotal = (group ? group.totalCents : 0n) + cents;
    const nextTotal = totalCents + cents;

    if (nextGroupTotal > MAX_SAFE) {
      throw new Error(
        `Category "${category}" sum at line ${lineNo} exceeds Number.MAX_SAFE_INTEGER`
      );
    }
    if (nextTotal > MAX_SAFE) {
      throw new Error(
        `Total sum at line ${lineNo} exceeds Number.MAX_SAFE_INTEGER`
      );
    }

    if (group) {
      group.totalCents = nextGroupTotal;
      group.count += 1;
    } else {
      const created = {category, totalCents: nextGroupTotal, count: 1};
      byCategory.set(category, created);
      groups.push(created);
    }

    totalCents = nextTotal;
    count += 1;
  }

  return {
    groups: groups.map((g) => ({
      category: g.category,
      totalCents: Number(g.totalCents),
      count: g.count,
    })),
    totalCents: Number(totalCents),
    count,
  };
}

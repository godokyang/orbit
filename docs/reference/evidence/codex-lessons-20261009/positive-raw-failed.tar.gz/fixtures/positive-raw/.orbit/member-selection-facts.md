# Member selection facts — importer.mjs work unit (2026-10-09)

Candidates in pool, facts from public sources only (accessed 2026-10-09):

| Member | Facts | Source & date | Limits |
|---|---|---|---|
| zhipu-coding-plan/glm-5.3-flash | Terminal-Bench 2.1: 84.3; DeepSWE v1.1: 63.4 (vs GLM-5.2's 46.2); MoE, NGC release 2026-08-31 | datacamp.com/blog/glm-5-3-flash; catalog.ngc.nvidia.com (zai-org/glm-5.3-flash) | Vendor-adjacent blog figures; TB version 2.1 not 3.0 |
| opencode-go/deepseek-v4.1-flash | Released 2026-09-10, open weight; NL2Repo-Bench 65.4%; Terminal-Bench 3.0: 30%; Terminal-Bench 2.1: 90.6% | aireleasetracker.com/model/deepseek/deepseek-v4.1-flash | Third-party tracker; conflicting TB2.1 vs vendor-adjacent GLM figure |
| cursor/grok-4.7 | Coding-autonomy upgrades; CursorBench/AA-Briefcase "just behind Claude Fable 5.1"; no hard scores found | androidheadlines.com 2026-09 | Qualitative only, no numeric scores gathered |
| kimi-code/k3-256k, openai-codex/gpt-6.1-sol, openai-codex/gpt-6-luna, zenmux/deepseek-v4.1-flash, cursor/grok-4.7-fast | No verifiable numeric coding facts found | — | Not assessed; no capability inferred from names |

## Decision
Choose **orbit-m-zhipu-coding-plan-glm-5-3-flash-71b48ce8** for the importer unit: it has the most concrete, multiply-sourced agentic-coding scores (TB 2.1 84.3 / DeepSWE 63.4), release facts confirmed by NVIDIA NGC, and shares the root model family. deepseek-v4.1-flash shows a higher TB 2.1 figure but mixed TB 3.0 evidence and weaker source triangulation.
Member scope: read tests/acceptance.mjs + SPEC.md, edit src/importer.mjs only, no shell/npm/tests; Root owns CLI, README, integration, and all execution verification.

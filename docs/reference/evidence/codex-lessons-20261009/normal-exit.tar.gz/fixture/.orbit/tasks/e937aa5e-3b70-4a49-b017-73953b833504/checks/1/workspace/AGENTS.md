Only change greeting.mjs. Do not commit, push, install dependencies or use network.

#!/usr/bin/env node
import fs from 'node:fs';
import {importExpenses} from './importer.mjs';

const args = process.argv.slice(2);

function fail(message) {
  console.error(`expense-importer: ${message}`);
  process.exit(1);
}

if (args.length !== 1) {
  fail('expected exactly one path argument');
}

const file = args[0];

try {
  const text = fs.readFileSync(file, 'utf8');
  process.stdout.write(JSON.stringify(importExpenses(text)) + '\n');
} catch (err) {
  fail(err instanceof Error ? err.message : String(err));
}

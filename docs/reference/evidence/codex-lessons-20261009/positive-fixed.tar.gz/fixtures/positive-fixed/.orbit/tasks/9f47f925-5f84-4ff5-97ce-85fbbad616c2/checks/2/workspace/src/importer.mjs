const HEADER = 'category,amount';
const AMOUNT_RE = /^\d+\.\d{2}$/;
const MAX_SAFE = BigInt(Number.MAX_SAFE_INTEGER);

function fail(line, message) {
  throw new Error(`line ${line}: ${message}`);
}

// Integer cents from a validated amount string, using only BigInt integer
// arithmetic so no precision is lost regardless of input magnitude.
function toCents(amount, line) {
  const dot = amount.indexOf('.');
  const whole = BigInt(amount.slice(0, dot));
  const frac = BigInt(amount.slice(dot + 1));
  const cents = whole * 100n + frac;
  if (cents > MAX_SAFE) fail(line, `amount ${amount} exceeds Number.MAX_SAFE_INTEGER`);
  return cents;
}

export function importExpenses(text) {
  // Strip exactly one leading BOM.
  const body = text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;
  const lines = body.split(/\r\n|\n/);

  if (lines[0] !== HEADER) fail(1, `expected header "${HEADER}"`);

  const groups = new Map();
  let totalCents = 0n;
  let count = 0;

  for (let i = 1; i < lines.length; i++) {
    const lineNo = i + 1;
    const raw = lines[i];
    if (raw.trim() === '') continue; // blank lines ignored, still numbered

    const columns = raw.split(',');
    if (columns.length !== 2) fail(lineNo, 'expected exactly two columns');
    const category = columns[0].trim();
    const amount = columns[1].trim();
    if (category === '') fail(lineNo, 'category must not be empty');
    if (!AMOUNT_RE.test(amount)) fail(lineNo, `invalid amount "${amount}"`);

    const cents = toCents(amount, lineNo);

    let group = groups.get(category);
    if (group === undefined) {
      group = {category, totalCents: 0n, count: 0};
      groups.set(category, group);
    }
    group.totalCents += cents;
    group.count += 1;
    if (group.totalCents > MAX_SAFE) {
      fail(lineNo, `category "${category}" total exceeds Number.MAX_SAFE_INTEGER`);
    }

    totalCents += cents;
    if (totalCents > MAX_SAFE) fail(lineNo, 'total exceeds Number.MAX_SAFE_INTEGER');
    count += 1;
  }

  return {
    groups: [...groups.values()].map((g) => ({
      category: g.category,
      totalCents: Number(g.totalCents),
      count: g.count,
    })),
    totalCents: Number(totalCents),
    count,
  };
}

# expense-importer

CSV expense summarizer. Reads `category,amount` CSV, groups by category, and totals amounts as exact integer cents.

## Usage

```sh
node src/cli.mjs input.csv
```

Prints the summary JSON to stdout and exits 0:

```json
{"groups":[{"category":"Food","totalCents":122,"count":2}],"totalCents":122,"count":2}
```

On any failure (wrong argument count, unreadable file, invalid CSV) it prints a concise error to stderr, writes nothing to stdout, and exits 1. No stack trace.

## Input format

- First line must be the header `category,amount` (an optional leading UTF-8 BOM is stripped).
- Data lines are `category,amount`, unquoted, exactly two columns; both fields are trimmed.
- Blank lines are ignored (but still counted for error line numbers).
- Amounts are nonnegative decimals with exactly two fractional digits (e.g. `1.20`); signs, exponents, and other decimal counts are rejected.
- Category must be nonempty.

## Ordering and precision

- Categories appear in the output in first-seen order.
- All totals are computed as exact integer cents; any amount or sum exceeding `Number.MAX_SAFE_INTEGER` is rejected with an error naming the one-based source line (blank lines included in numbering).

## Library

```js
import {importExpenses} from './src/importer.mjs';
importExpenses(text); // same result object; throws Error with line number on invalid input
```

## Tests

```sh
npm test
```

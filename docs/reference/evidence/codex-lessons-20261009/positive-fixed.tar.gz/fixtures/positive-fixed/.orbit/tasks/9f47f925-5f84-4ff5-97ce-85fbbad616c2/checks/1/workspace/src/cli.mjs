// Acceptance baseline: CLI implementation is assigned to the tested Root.
throw new Error("not implemented");

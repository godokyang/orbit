{
  "file": "src/importer.mjs",
  "status": "implemented",
  "summary": "Implemented importExpenses(text) per SPEC.md and tests/acceptance.mjs.",
  "key_decisions": [
    "BOM: strip exactly one leading U+FEFF via charCodeAt(0)===0xFEFF.",
    "Line splitting: normalized.split(/\\r?\\n/) handles LF and CRLF.",
    "Header check on lines[0] after BOM strip: must be exactly 'category,amount', else 'Line 1: ...'. No trim on header (exactness preserved).",
    "Blank detection uses raw.trim()==='' (empty and whitespace-only lines skipped) while maintaining one-based numbering (header=1).",
    "CSV split on ',' with strict columns.length===2 (no quoting support, matches unquoted-CSV contract).",
    "Amount validated with /^\\d+\\.\\d{2}$/ (rejects sign, exponent, wrong decimal count).",
    "Funding: cents computed via BigInt — BigInt(intPart)*100n + BigInt(fracPart); no floating point anywhere.",
    "Overflow: BigInt compare against BigInt(Number.MAX_SAFE_INTEGER) after each amount, each per-category running sum, and the overall running sum; each check throws an Error containing the current one-based line number.",
    "Order: Map preserves first-seen category order; output groups pushed in insertion order.",
    "Return shape: {groups:[{category,totalCents:Number,count}],totalCents:Number,count:Number} (BigInt converted to Number only after MAX_SAFE check guarantees exactness)."
  ],
  "deviations_or_conflicts": "none",
  "verification_left_to_root": "Run `node tests/acceptance.mjs` (all importer cases plus CLI cases). I had no shell access, so I could not execute it."
}